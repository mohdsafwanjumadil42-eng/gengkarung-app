package com.gengkarung.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
