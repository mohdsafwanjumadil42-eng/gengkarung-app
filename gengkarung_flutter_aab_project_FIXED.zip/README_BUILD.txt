GENGKARUNG AAB

1. Install Flutter stable and Android Studio.
2. Open this project folder in Android Studio or VS Code.
3. Run:
   flutter pub get
4. Build AAB:
   flutter build appbundle --release
5. The AAB will be created at:
   build/app/outputs/bundle/release/app-release.aab

Website:
https://gengkarung.com

Package:
com.gengkarung.app

Nota:
- Website dibuka dalam WebView.
- JavaScript diaktifkan.
- Butang Back kembali ke halaman WebView dahulu.
- Untuk Google Play, anda masih perlu sediakan app icon, signing/keystore dan maklumat Play Console jika belum ada.


FIX BUILD:
- styles.xml menggunakan Android built-in Theme.Material.Light.NoActionBar.
- Ini membetulkan error AAPT: resource android:style/Theme.Light.NoActionBar not found.
